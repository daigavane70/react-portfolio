import java.rmi.Naming;

public class AddClient {
    public static void main(String[] args) {
        try {
            String addServer = "rmi://"+args[0]+"/AddServer";
            AddServerIntf addServerIntf = (AddServerIntf)Naming.lookup(addServer);

            double d1 = Double.valueOf(args[1]);
            double d2 = Double.valueOf(args[2]);

            System.out.println("Sum of two numbers: "+addServerIntf.add(d1, d2));
        } catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
}
