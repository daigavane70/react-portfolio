import java.rmi.*;

public interface AddServerIntf extends Remote {
    double add(double n1, double n2) throws RemoteException;
}