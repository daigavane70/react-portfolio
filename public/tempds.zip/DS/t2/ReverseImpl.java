package t2;

public class ReverseImpl {
    public ReverseImpl() {
        System.out.println("Reverse object created");
    }

    public String reverse_string(String str1, String str2) {
        return str1 + str2;
    }
}
